import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../components/components.module'
import { AndroidSmall1 } from './android-small1.component'

const routes = [
  {
    path: '',
    component: AndroidSmall1,
  },
]

@NgModule({
  declarations: [AndroidSmall1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [AndroidSmall1],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AndroidSmall1Module {}
