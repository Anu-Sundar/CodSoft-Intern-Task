import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'android-small1',
  templateUrl: 'android-small1.component.html',
  styleUrls: ['android-small1.component.css'],
})
export class AndroidSmall1 {
  raw7y93: string = ' '
  rawjirl: string = ' '
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
