import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'android-small3',
  templateUrl: 'android-small3.component.html',
  styleUrls: ['android-small3.component.css'],
})
export class AndroidSmall3 {
  raw4yik: string = ' '
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
