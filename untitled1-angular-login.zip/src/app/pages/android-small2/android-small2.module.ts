import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../components/components.module'
import { AndroidSmall2 } from './android-small2.component'

const routes = [
  {
    path: '',
    component: AndroidSmall2,
  },
]

@NgModule({
  declarations: [AndroidSmall2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [AndroidSmall2],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AndroidSmall2Module {}
