import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'android-small2',
  templateUrl: 'android-small2.component.html',
  styleUrls: ['android-small2.component.css'],
})
export class AndroidSmall2 {
  raw06du: string = ' '
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
