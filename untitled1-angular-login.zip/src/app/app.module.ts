import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { RouterModule } from '@angular/router'
import { BrowserModule } from '@angular/platform-browser'

import { ComponentsModule } from './components/components.module'
import { AppComponent } from './app.component'

const routes = [
  {
    path: '',
    loadChildren: () =>
      import('./pages/android-small1/android-small1.module').then(
        (m) => m.AndroidSmall1Module
      ),
  },
  {
    path: 'android-small2',
    loadChildren: () =>
      import('./pages/android-small2/android-small2.module').then(
        (m) => m.AndroidSmall2Module
      ),
  },
  {
    path: 'android-small3',
    loadChildren: () =>
      import('./pages/android-small3/android-small3.module').then(
        (m) => m.AndroidSmall3Module
      ),
  },
  {
    path: '**',
    loadChildren: () =>
      import('./pages/not-found/not-found.module').then(
        (m) => m.NotFoundModule
      ),
  },
]

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, RouterModule.forRoot(routes), ComponentsModule],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule {}
