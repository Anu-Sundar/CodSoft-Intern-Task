import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../components/components.module'
import { Kuta } from './kuta.component'

const routes = [
  {
    path: '',
    component: Kuta,
  },
]

@NgModule({
  declarations: [Kuta],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Kuta],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class KutaModule {}
