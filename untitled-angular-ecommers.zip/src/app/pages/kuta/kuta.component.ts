import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-kuta',
  templateUrl: 'kuta.component.html',
  styleUrls: ['kuta.component.css'],
})
export class Kuta {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
